# XakaVisuals

Client-side Fabric mod project for Minecraft 1.21.4, Java 21.

## Included
- Right Shift opens the XakaVisuals ClickGUI.
- Four sections: Visuals, HUD, Effects, Settings.
- Animated panel entrance and five accent colors.
- HUD preference toggles are represented in the interface.

## Build
Run `gradle build` with Java 21 and network access. The resulting mod JAR is written to `build/libs/`.

This is an early UI build. The visible HUD and visual toggles are configuration/UI scaffolding; they do not yet implement all corresponding in-game render features. The project has not been compiled or tested in Minecraft yet.
